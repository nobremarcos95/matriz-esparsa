#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>


//identifica se esta rodando em windows ou outro S.O.
#if defined(_WIN32) || defined(WIN32)
#define clearBuffer() fflush(stdin)
#define clearScreen() system("cls")
#else
#include <stdio_ext.h>
#define clearBuffer() __fpurge(stdin)
#define clearScreen() system("clear")
#endif


typedef struct noh_matriz
{
    float valor;
    int coluna;
    struct noh_matriz *prox;
} Noh;


typedef Noh *ptr;


typedef struct t_matriz
{
    ptr *matr;
    int linhas;
    int colunas;
} Matriz;


void inicializaMatriz(Matriz *mtz, int lin, int col);
int atribuiMatriz(Matriz *mtz, int lin, int col, float valor);
float buscaElemento(Matriz *mtz, int lin, int col);
float somaLinha(Matriz *mtz, int lin);
float somaColuna(Matriz *mtz, int lin, int col);


int main()
{
    float somaL, somaC;                     //variaveis de retorno das funcoes de soma
    float number, num;                      //retorno da funcao buscaElemento e valor inserido
    int option;                             //variavel para o switch
    int line, col2;                         //variaves para os retornos das funcoes somaLinha e somaColuna
    int linepos, colpos, linecons, colcons; //variaveis para insercao e consulta na matriz
    int row, column;                        //row e column sao as dimensoes da matriz
    int vrf, inicio = 0;                    //variaveis de verificacao

    Matriz *matrix;

    do
    {
        clearScreen();
        printf("\t === OPCOES ===\n");
        printf("1. Criar uma matriz\n");
        printf("2. Inserir um valor numa posicao da matriz\n");
        printf("3. Consultar um valor numa posicao da matriz\n");
        printf("4. Fornecer a soma de uma linha da matriz\n");
        printf("5. Fornecer a soma de uma coluna da matriz\n");
        printf("6. Excluir a matriz\n");
        printf("0. Sair\n");

        clearBuffer();
        scanf("%d", &option);
        switch(option)
        {
        case 1:
            clearScreen();
            matrix = (Matriz *) calloc(1, sizeof(Matriz));
            if (!matrix)
            {
                printf("ERRO NA ALOCACAO DE MEMORIA.\n");
                clearBuffer();
                getchar();
                exit(1);
            }
            printf("Digite a quantidade de linhas da matriz: ");
            clearBuffer();
            scanf("%d", &row);

            printf("Digite a quantidade de colunas da matriz: ");
            clearBuffer();
            scanf("%d", &column);

            inicializaMatriz(matrix, row, column);
            inicio = 1;
            break;
        case 2:
            if (inicio != 1)
            {
                clearScreen();
                printf("Primeiro crie a matriz, por favor.\n");
                clearBuffer();
                getchar();
                break;
            }
            clearScreen();
            printf("Informe o valor a ser inserido: ");
            clearBuffer();
            scanf("%f", &num);

            printf("Informe a linha desejada: ");
            clearBuffer();
            scanf("%d", &linepos);
            while ((linepos < 0) || (linepos > row))
            {
                printf("Linha invalida. Tente novamente.\n");
                clearBuffer();
                scanf("%d", &linepos);
            }

            printf("Informe a coluna desejada: ");
            clearBuffer();
            scanf("%d", &colpos);
            while ((colpos < 0) || (colpos > column))
            {
                printf("Coluna invalida. Tente novamente.\n");
                clearBuffer();
                scanf("%d", &colpos);
            }

            vrf = atribuiMatriz(matrix, linepos, colpos, num);
            if (vrf == 0)
            {
                printf("Nao foi possivel inserir o elemento.\nPor favor, tente novamente.\n");
                clearBuffer();
                getchar();
            }
            else
            {
                printf("Elemento inserido com sucesso.\n");
                clearBuffer();
                getchar();
            }
            break;
        case 3:
            if (inicio != 1)
            {
                clearScreen();
                printf("Primeiro crie a matriz, por favor.\n");
                clearBuffer();
                getchar();
                break;
            }
            clearScreen();
            printf("Informe a posicao a ser consultada:\nLinha: ");
            clearBuffer();
            scanf("%d", &linecons);
            while ((linecons < 0) || (linecons > row))
            {
                printf("Linha invalida. Tente novamente.\n");
                clearBuffer();
                scanf("%d", &linecons);
            }

            printf("Coluna: ");
            clearBuffer();
            scanf("%d", &colcons);
            while ((colcons < 0) || (colcons > column))
            {
                printf("Coluna invalida. Tente novamente.\n");
                clearBuffer();
                scanf("%d", &colcons);
            }
            number = buscaElemento(matrix, linecons, colcons);
            printf("Valor na Linha %d e Coluna %d: %.2f\n", linecons, colcons, number);
            clearBuffer();
            getchar();
            break;
        case 4:
            if (inicio != 1)
            {
                clearScreen();
                printf("Primeiro crie a matriz, por favor.\n");
                clearBuffer();
                getchar();
                break;
            }
            clearScreen();
            printf("Informe a linha desejada: ");
            clearBuffer();
            scanf("%d", &line);
            while ((line < 0) || (line > row))
            {
                printf("Linha invalida. Tente novamente.\n");
                clearBuffer();
                scanf("%d", &line);
            }
            somaL = somaLinha(matrix, line);
            printf("Soma dos elementos da linha %d = %.2f\n", line, somaL);
            clearBuffer();
            getchar();
            break;
        case 5:
            if (inicio != 1)
            {
                clearScreen();
                printf("Primeiro crie a matriz, por favor.\n");
                clearBuffer();
                getchar();
                break;
            }
            clearScreen();
            printf("Informe a coluna desejada: ");
            clearBuffer();
            scanf("%d", &col2);
            while ((col2 < 0) || (col2 > column))
            {
                printf("Coluna invalida. Tente novamente.\n");
                clearBuffer();
                scanf("%d", &col2);
            }
            somaC = somaColuna(matrix, 0, col2);
            printf("Soma dos elementos da coluna %d = %.2f\n", col2, somaC);
            clearBuffer();
            getchar();
            break;
        case 6:
            clearScreen();
            inicio = 0;
            free(matrix);
            printf("Matriz excluida com sucesso.\n");
            clearBuffer();
            getchar();
            break;
        case 0:
            exit(0);
            break;
        default:
            printf("Opcao invalida!\n");
            clearBuffer();
            getchar();
            break;
        }
    } while (option != 0);

    free(matrix);
    return 0;
}


void inicializaMatriz(Matriz *mtz, int lin, int col)
{
    int i;
    mtz->linhas = lin;
    mtz->colunas = col;
    mtz->matr = (ptr *) calloc(lin, sizeof(ptr));
    if (!(mtz->matr))
    {
        printf("ERRO NA ALOCACAO DA MATRIZ.\n");
        clearBuffer();
        getchar();
        exit(1);
    }
    else
    {
        printf("\nMatriz %dx%d criada com sucesso.\n", lin, col);
        clearBuffer();
        getchar();
    }
    for (i = 0; i < lin; i++)
    {
        mtz->matr[i] = NULL;
    }
}


//insere um valor numa posicao da matriz determinada pelo usuario
int atribuiMatriz(Matriz *mtz, int lin, int col, float valor)
{
    ptr ant = NULL;
    ptr atual = mtz->matr[lin];

    while ((atual != NULL) && (atual->coluna < col))
    {
        ant = atual;
        atual = atual->prox;
    }
    if ((atual != NULL) && (atual->coluna == col))
    {
        if (valor == 0)
        {
            if (ant == NULL)
            {
                mtz->matr[lin] = atual->prox;
            }
            else
            {
                ant->prox = atual->prox;
            }
            free(atual);
        }
        atual->valor = valor;
    }
    else
    {
        ptr novo = (ptr) calloc(1, sizeof(Noh));
        novo->coluna = col;
        novo->valor = valor;
        novo->prox = atual;
        if (ant == NULL)
        {
            mtz->matr[lin] = novo;
        }
        else
        {
            ant->prox = novo;
        }
    }
    return 1;
}


//esta funcao retorna o numero existente na posicao da matriz determinada pelo usuario
float buscaElemento(Matriz *mtz, int lin, int col)
{
    ptr atual = mtz->matr[lin];

    while ((atual != NULL) && (atual->coluna < col))
    {
        atual = atual->prox;
    }
    if ((atual != NULL) && (atual->coluna == col))
    {
        return (atual->valor);
    }
    return 0;
}


float somaLinha(Matriz *mtz, int lin)
{
    ptr atual = mtz->matr[lin];
    float soma = 0.0;

    while ((atual != NULL) && ((atual->coluna) < (mtz->colunas)))
    {
        soma = soma + (atual->valor);
        atual = atual->prox;
    }
    return soma;
}


float somaColuna(Matriz *mtz, int lin, int col)
{
    float soma = 0.0;
    ptr actual = mtz->matr[lin];
    while (lin < mtz->linhas)
    {
        actual = mtz->matr[lin];
        while ((actual != NULL) && (actual->coluna < col))
        {
            actual = actual->prox;
        }
        if ((actual != NULL) && actual->coluna == col)
        {
            soma = soma + (actual->valor);
        }
        lin = lin + 1;
    }

    return soma;
}

