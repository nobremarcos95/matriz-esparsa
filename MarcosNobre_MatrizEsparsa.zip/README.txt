Este trabalho visa implementar um programa em linguagem C 
para criar e/ou excluir uma matriz esparsa de dimensões 
inicialmente indeterminadas, e também realizar algumas 
operações, como soma dos elementos de uma linha ou 
de uma coluna.


Integrante: Marcos Antonio Nobre Coutinho (p=0)
NUSP = 10716397